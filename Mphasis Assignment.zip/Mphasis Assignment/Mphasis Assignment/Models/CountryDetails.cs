﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mphasis_Assignment.Models
{
    public class CountryDetails
    {
        public string CountryName { get; set; }
        public string Culture { get; set; }
    }
}
