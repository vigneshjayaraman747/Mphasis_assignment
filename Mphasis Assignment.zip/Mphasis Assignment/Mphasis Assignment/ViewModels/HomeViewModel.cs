﻿using Mphasis_Assignment.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Input;

namespace Mphasis_Assignment.ViewModels
{
    public class HomeViewModel : INotifyPropertyChanged
    {
        private string _number1;
        private string _number2;
        private string _number3;
        private ObservableCollection<CountryDetails> _countryList;
        private CountryDetails _selectedCountry;
        private ObservableCollection<string> _status;
        private bool _isInProgress;

        
        public ICommand ProcessDataCommand { get; set; }

        public HomeViewModel()
        {
            _countryList = new ObservableCollection<CountryDetails>
            {
                new CountryDetails() { CountryName = "United State", Culture = "en-US"},
                new CountryDetails() { CountryName = "France", Culture = "fr-FR"}
            };

            this.SetCountryDefault();
            _status = new ObservableCollection<string>();
            ProcessDataCommand = new RelayCommand(ProcessDataCommandHandler, CanExecuteProcessData);
        }

        public string Number1
        {
            get { return _number1; }
            set
            {
                if (_number1 != value)
                {
                    _number1 = value;
                    RaisePropertyChanged("Number1");
                }
            }
        }

        public string Number2
        {
            get { return _number2; }
            set
            {
                if (_number2 != value)
                {
                    _number2 = value;
                    RaisePropertyChanged("Number2");
                }
            }
        }

        public string Number3
        {
            get { return _number3; }
            set
            {
                if (_number3 != value)
                {
                    _number3 = value;
                    RaisePropertyChanged("Number3");
                }
            }
        }

        public ObservableCollection<CountryDetails> CountryList
        {
            get { return _countryList; }
            set
            {
                if (_countryList != value)
                {
                    _countryList = value;
                    RaisePropertyChanged("CountryList");
                }
            }
        }

        public CountryDetails SelectedCountry
        {
            get { return _selectedCountry; }
            set
            {
                if (_selectedCountry != value)
                {
                    _selectedCountry = value;
                    RaisePropertyChanged("SelectedCountry");
                }
            }
        }

        public ObservableCollection<string> Status
        {
            get { return _status; }
            set
            {
                if (_status != value)
                {
                    _status = value;
                    RaisePropertyChanged("Status");
                }
            }
        }

        private void ProcessDataCommandHandler()
        {
            _isInProgress = true;
            bool isValid = true;
            float number1;
            float number2;
            int number3;

            this.Status.Clear();

            //try converting the given value with selected country culture
            if (!float.TryParse(this.Number1, NumberStyles.AllowDecimalPoint,
                new CultureInfo(this.SelectedCountry.Culture),
                out number1))
            {
                this.Status.Add($"The given Number 1: '{Number1}' is not valid in selected country format.");
                isValid = false;
            }
            else
            {
                //regular expression to validate the given value, Matches if value has max 3 decimal points
                var regex = @"^[0-9]{1,11}(?:\.[0-9]{1,3})?$";

                if (!Regex.IsMatch(number1.ToString(), regex))
                {
                    this.Status.Add($"The given Number 1: '{Number1}' is not valid in selected country format.");
                    isValid = false;
                }
            }

            if (!float.TryParse(this.Number2, NumberStyles.AllowDecimalPoint,
                new CultureInfo(this.SelectedCountry.Culture),
                out number2))
            {

                this.Status.Add($"The given Number 2: '{Number2}' is not valid in selected country format.");
                isValid = false;
            }
            else
            {
                var regex = @"^[0-9]{1,11}(?:\.[0-9]{1,3})?$";

                if (!Regex.IsMatch(number2.ToString(), regex))
                {
                    this.Status.Add($"The given Number 2: '{Number2}' is not valid in selected country format.");
                    isValid = false;
                }
            }

            if (!int.TryParse(this.Number3,out number3))
            {
                this.Status.Add($"The given Number 3: '{Number3}' is not valid  in selected country format.");
                isValid = false;
            }
            else
            {
                var regex = @"^[0-9]+$";
                if (!Regex.IsMatch(number3.ToString(), regex))
                {
                    this.Status.Add($"The given Number 2: '{Number3}' is not valid in selected country format.");
                    isValid = false;
                }
            }

            if (isValid)
            {
                this.Status.Add("You have entered the valid numbers :-)");
                this.Status.Add("Sorting the entered value.");

                // Sort the value
                FloatComparer floatComparer = new FloatComparer();
                var enteredValueList = new List<float>() { number1, number2, number3 };
                enteredValueList.Sort(floatComparer);

                this.Status.Add("Result:");
                foreach (var num in enteredValueList)
                {
                    this.Status.Add(num.ToString(new CultureInfo(this.SelectedCountry.Culture)));
                }
            }

            //home directory of the current user + filename
            StoresortedData(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\werte.txt", this.Status);
            _isInProgress = false;
        }


        private void StoresortedData(string filepath, object data)
        {
            using (TextWriter tw = new StreamWriter(filepath))
            {
                foreach (var item in (ObservableCollection<string>)data)
                {
                    tw.WriteLine(item.ToString());
                }

                tw.Flush();
                tw.Close();
            }
            this.Status.Add("Result stored in: " + filepath);
        }
        private bool CanExecuteProcessData()
        {
            return !_isInProgress;
        }

        private void SetCountryDefault()
        {
            if (this.CountryList.Any())
            {
                this.SelectedCountry = this.CountryList.FirstOrDefault();
            }
        }



        //Notify the GUI if property value changed
        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChanged(string propname)
        {
            if (PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propname));
            }
        }

    }



    public class FloatComparer : IComparer<float>
    {
        public int Compare(float x, float y)
        {
            if (x == 0 || y == 0)
            {
                return 0;
            }

            return x.CompareTo(y);

        }
    }

    public class RelayCommand : ICommand
    {
        private Action _execute;
        private Func<bool> _canexecute;

        public RelayCommand(Action _execute, Func<bool> _canexecute)
        {
            this._execute = _execute;
            this._canexecute = _canexecute;
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }

            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return _canexecute();
        }

        public void Execute(object parameter)
        {
            this._execute();
        }
    }
}
